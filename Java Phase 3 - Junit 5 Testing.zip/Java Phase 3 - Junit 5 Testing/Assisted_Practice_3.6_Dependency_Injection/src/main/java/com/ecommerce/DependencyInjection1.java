package com.ecommerce;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
@DisplayName("JUnit 5 Dependency Injection Example")
class DependencyInjection1 {

	DependencyInjection1(TestInfo testinfo){
		assertEquals("JUnit 5 Dependency Injection Example", testinfo.getDisplayName());
	}
	@BeforeEach
	void init(TestInfo testinfo) {
		String displayName=testinfo.getDisplayName();
		assertTrue(displayName.equals("TEST 1") || displayName.equals("test2()"));     //failed test
	}
	@Test
	@DisplayName("TEST 1")
	@Tag("my-tag")
	void test1(TestInfo testinfo) {
		assertEquals("TEST 1", testinfo.getDisplayName());
		assertTrue(testinfo.getTags().contains("my-tag"));
	}
}
