
package com.ecommerce;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import com.ecommerce.Calculation;

/**
 * @author Intel
 *
 */
class RepeatedSameTest {

	@Test
	@DisplayName("Add operation test")
	@RepeatedTest(5)
	void test() {
		Calculation obj=new Calculation();
		assertEquals(2, obj.addition(1,1), "1+1 should equal 2");
		System.out.println("Testcase executed");
		
	}

}
