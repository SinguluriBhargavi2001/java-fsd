package com.ecommerce;

public class Calculation {
	public int addition(int n1, int n2) {
		return n1+n2;
	}
}
