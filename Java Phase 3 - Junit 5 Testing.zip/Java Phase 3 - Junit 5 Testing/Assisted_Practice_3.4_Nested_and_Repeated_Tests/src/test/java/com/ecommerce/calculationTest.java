package com.ecommerce;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ecommerce.Calculation;

class calculationTest {
	
	@Test
	void test() {
		Calculation obj=new Calculation();
		assertEquals(8, obj.addition(2, 3));
	}

}
