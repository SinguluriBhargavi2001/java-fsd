package com.ecommerce;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

class DynamicTests {
	String s="Singuluri's";
	int a=s.length();
	@TestFactory
	Collection<DynamicTest> dynamictestwithCollection(){
		return Arrays.asList(
				DynamicTest.dynamicTest("Add Test", ()->assertEquals(2, Math.addExact(1, 1))),
				DynamicTest.dynamicTest("Multiply Test", ()->assertEquals(6, Math.multiplyExact(2, 3))),
				DynamicTest.dynamicTest("Length of string is 11 or not", ()->assertEquals(11,a))
				);
	}
	
}
