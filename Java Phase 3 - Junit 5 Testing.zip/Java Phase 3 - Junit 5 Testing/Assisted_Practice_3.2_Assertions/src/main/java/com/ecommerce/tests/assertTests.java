package com.ecommerce.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class assertTests {

	@Test
	public void test() {
		String str="Hello";
		String str1="HelloWorld";
		int[] a1= {1,2};
		int[] a2= {1,2};
		assertTrue(4>0); //pass
		
		assertFalse(5<2); //pass
		
		assertNull(null); //pass
		
		assertNotNull(str); //pass
		
		assertSame(str, str); //pass
		
		assertNotSame(str,str1); //pass
		
		assertEquals(5,5); //pass
		
		assertNotEquals(2,3); //pass
		
		assertArrayEquals(a1,a2); //pass
		
		assertSame(a1,a2); //fail
		
		assertThrows(RuntimeException.class, () -> {throw new RuntimeException();  //Lambda Expression
	});

}
}

/* Example for lamda expression
 * interface Greeting{
 * String greet(String msg);}
 *  
 *  Class classA{
 *  public static void main(String[] args){
 *  Greeting obj = (msg) -> System.out.println(msg);
 *  obj.greet("Hello");
 *  }
 *  }
 *  */
