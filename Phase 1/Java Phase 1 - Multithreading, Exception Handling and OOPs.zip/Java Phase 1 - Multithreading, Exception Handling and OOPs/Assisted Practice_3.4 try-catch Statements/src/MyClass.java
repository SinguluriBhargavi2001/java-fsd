public class MyClass 
{
    public static void main(String args[]) 
    {
        int[] array = new int[3];
        try 
        {
            array[7] = 3;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds!"); 
        }
        finally 
        {
            System.out.println("The array is of size " + array.length);
        }
    }
}

//Method 2

/*public class MyClass{
	public void method1(){
		int[] array = new int[3];
		try {
			System.out.println(array[5]);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		 finally 
        {
            System.out.println("The array is of size " + array.length);
        }
	}
	public static void main(String[] args) {
		MyClass c=new MyClass();
		c.method1();
	}
}*/
