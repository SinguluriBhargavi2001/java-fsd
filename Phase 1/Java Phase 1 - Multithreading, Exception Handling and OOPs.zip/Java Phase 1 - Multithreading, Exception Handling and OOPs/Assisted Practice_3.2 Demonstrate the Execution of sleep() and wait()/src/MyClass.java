public class MyClass
{
    private static Object LOCK = new Object();
    static MyClass obj=new MyClass();
    public static void main(String args[]) throws InterruptedException
    {
        Thread.sleep(1000);
        System.out.println("Thread '" + Thread.currentThread().getId() + "' is woken after sleeping for 1 second");
        try {
            obj.wait(3000);
            System.out.println("Object '" + obj + "' is woken after" + " waiting for 3 second");
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
        synchronized (LOCK) 
        {
            LOCK.wait(1000);
            System.out.println("Object '" + LOCK + "' is woken after" + " waiting for 1 second");
        }
    }
}
//wait- this method is used for Object class
//sleep- this method is used for Thread class