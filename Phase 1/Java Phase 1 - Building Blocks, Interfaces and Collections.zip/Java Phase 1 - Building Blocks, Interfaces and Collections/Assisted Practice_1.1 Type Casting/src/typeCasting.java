public class typeCasting {

	public static void main(String[] args) {
		//Implicit Type casting
		char c='A';
		int n=c;
		System.out.println("Implicit conversion from char to int: "+c+" --> "+n);
		
		long n1=c;
		System.out.println("Implicit conversion from char to long: "+c+" --> "+n1);
		
		float n2=c;
		System.out.println("Implicit conversion from char to float: "+c+" --> "+n2);
		
		double n3=c;
		System.out.println("Implicit conversion from char to double: "+c+" --> "+n3);
		
		//Explicit Type casting 
		char a=(char)n;
		System.out.println("Explicit conversion from int to char: "+n+" --> "+a);
	}
}
